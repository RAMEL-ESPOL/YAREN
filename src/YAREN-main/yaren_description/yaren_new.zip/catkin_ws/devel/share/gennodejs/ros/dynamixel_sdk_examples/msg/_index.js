
"use strict";

let SetPosition = require('./SetPosition.js');

module.exports = {
  SetPosition: SetPosition,
};
